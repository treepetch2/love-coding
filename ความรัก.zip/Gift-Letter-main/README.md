# Thư tỏ tình 4.0 💌
---
Tác giả chính: [Heryoka Kurniawan](https://github.com/heryyy)

Tham khảo: [Src Code gốc](https://github.com/heryyy/pink-envelope)

---
<img width="1919" height="1079" alt="image" src="https://github.com/user-attachments/assets/2d97a76e-c66e-40b4-9911-160cd0b2ace5" />
